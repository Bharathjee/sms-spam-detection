import argparse
import joblib
import json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Path to joblib model")
    ap.add_argument("--text", required=True, help="Message text to classify")
    args = ap.parse_args()

    pipe = joblib.load(args.model)
    proba = getattr(pipe, "predict_proba", None)
    label = pipe.predict([args.text])[0]
    score = None
    if proba is not None:
        # assume spam is class index where label == "spam"
        classes = list(pipe.classes_)
        if "spam" in classes:
            idx = classes.index("spam")
            score = float(proba([args.text])[0][idx])
    print(json.dumps({"label": label, "spam_probability": score}, indent=2))

if __name__ == "__main__":
    main()