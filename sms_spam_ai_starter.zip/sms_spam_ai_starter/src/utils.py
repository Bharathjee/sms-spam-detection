import re
from typing import List

URL_PATTERN = re.compile(r"(https?://\S+|www\.\S+)")
NON_ALPHA_NUM = re.compile(r"[^A-Za-z0-9\s]")

def basic_clean(text: str) -> str:
    # lowercase
    t = text.lower()
    # remove urls
    t = URL_PATTERN.sub(" URL ", t)
    # remove non alpha-num (keep spaces)
    t = NON_ALPHA_NUM.sub(" ", t)
    # collapse spaces
    t = re.sub(r"\s+", " ", t).strip()
    return t

def batch_clean(texts: List[str]) -> List[str]:
    return [basic_clean(t) for t in texts]