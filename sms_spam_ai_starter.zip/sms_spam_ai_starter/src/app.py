from fastapi import FastAPI
from pydantic import BaseModel
import joblib
from typing import Optional

app = FastAPI(title="SMS Spam Detector", version="1.0.0")

class Inp(BaseModel):
    text: str

class Out(BaseModel):
    label: str
    spam_probability: Optional[float] = None

# Lazy load model at startup (expects default path)
MODEL_PATH = "models/model.joblib"
_model = None

@app.on_event("startup")
def load_model():
    global _model
    try:
        _model = joblib.load(MODEL_PATH)
    except Exception as e:
        _model = None
        print(f"Warning: could not load model at {MODEL_PATH}: {e}")

@app.post("/predict", response_model=Out)
def predict(inp: Inp):
    if _model is None:
        return Out(label="unknown", spam_probability=None)
    proba = getattr(_model, "predict_proba", None)
    label = _model.predict([inp.text])[0]
    score = None
    if proba is not None:
        classes = list(_model.classes_)
        if "spam" in classes:
            idx = classes.index("spam")
            score = float(proba([inp.text])[0][idx])
    return Out(label=label, spam_probability=score)