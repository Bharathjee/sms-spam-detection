import argparse
import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score, precision_recall_fscore_support
from utils import basic_clean

def load_data(path: str):
    df = pd.read_csv(path)
    if not {'label','text'}.issubset(df.columns):
        raise ValueError("CSV must have columns: label,text")
    return df

def build_pipeline():
    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(
            preprocessor=basic_clean,
            ngram_range=(1,2),
            min_df=2,
            max_df=0.95
        )),
        ("clf", LogisticRegression(max_iter=200, n_jobs=None))
    ])
    return pipe

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="Path to CSV with columns label,text")
    ap.add_argument("--out", default="models/model.joblib", help="Where to save model")
    ap.add_argument("--test_size", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    df = load_data(args.data)
    X = df["text"].astype(str).tolist()
    y = df["label"].astype(str).tolist()

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=args.test_size, random_state=args.seed, stratify=y)

    pipe = build_pipeline()
    pipe.fit(X_train, y_train)

    # Evaluate
    y_pred = pipe.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(y_test, y_pred, average="binary", pos_label="spam")
    print("Accuracy:", round(acc, 4))
    print("Precision (spam):", round(prec, 4))
    print("Recall (spam):", round(rec, 4))
    print("F1 (spam):", round(f1, 4))
    print("\nDetailed report:\n")
    print(classification_report(y_test, y_pred))

    # Save
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    joblib.dump(pipe, args.out)
    print(f"\nSaved model to {args.out}")

if __name__ == "__main__":
    main()